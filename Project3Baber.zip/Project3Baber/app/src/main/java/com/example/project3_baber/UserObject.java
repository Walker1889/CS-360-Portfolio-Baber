package com.example.project2_baber;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Defines user class held within login database
// Has three columns, UserID, userName, password

@Entity
public class UserObject {
    @PrimaryKey
    public int UserID;

    @ColumnInfo(name = "username")
    public String userName;

    @ColumnInfo(name = "password")
    public String password;

    @ColumnInfo(name = "targetWeight")
    public int targetWeight;
}

