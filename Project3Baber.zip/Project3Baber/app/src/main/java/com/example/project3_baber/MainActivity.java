package com.example.project2_baber;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.*;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "users").build();
    }

    private boolean verifyLogin(String username, String password){
        LoginDAO logindao = database.logindao();
        UserObject user = logindao.findByName(username, password);
        return user != null;
    }

    private void createLogin(String username, String password){
        LoginDAO logindao = database.logindao();
        UserObject user = new UserObject();
        user.userName = username;
        user.password = password;
        logindao.insertAll(user);
    }

    public void RegisterClick(View view){
        EditText usernameRaw = findViewById(R.id.EditUserName);
        EditText passwordRaw = findViewById(R.id.EditPassword);
        String nameString = usernameRaw.getText().toString();
        String passwordString = passwordRaw.getText().toString();

        // REGISTER NEW USER --- NON-FUNCTIONAL
        /*if(!verifyLogin(nameString, passwordString)){
            createLogin(nameString, passwordString);
        }*/
    }

    public void LoginClick(View view){
        EditText usernameRaw = findViewById(R.id.EditUserName);
        EditText passwordRaw = findViewById(R.id.EditPassword);
        String nameString = usernameRaw.getText().toString();
        String passwordString = passwordRaw.getText().toString();

        // Placeholder Auto-login
        if(nameString.length() > 0 && passwordString.length() > 0) {
            setContentView(R.layout.activity_notification3);
        }

        // LOGIN USER --- NON-FUNCTIONAL
        /*if(verifyLogin(nameString, passwordString)){
            setContentView(R.layout.activity_notification3);
        }*/
    }




}