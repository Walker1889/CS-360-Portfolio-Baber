package com.example.project2_baber;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class Notification extends AppCompatActivity {

    Button allow;
    Button deny;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification3);

        allow = (Button) findViewById(R.id.AllowButton);
        deny = (Button) findViewById(R.id.DenyButton);

    }

    public void AllowClick(View view) {
        //Toast allowToast = Toast.makeText(getApplicationContext(), "Notifications Enabled", Toast.LENGTH_LONG);
        //allowToast.show();
        setContentView(R.layout.activity_main);
    }

    public void DenyClick(View view) {
        //Toast denyToast = Toast.makeText(getApplicationContext(), "Notifications Disabled", Toast.LENGTH_LONG);
        //denyToast.show();
        setContentView(R.layout.activity_data_display);
    }
    }


