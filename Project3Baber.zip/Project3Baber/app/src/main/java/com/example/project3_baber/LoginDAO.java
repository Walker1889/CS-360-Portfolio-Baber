package com.example.project2_baber;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LoginDAO {

    // Return all users
    @Query("SELECT * FROM userobject")
    List<UserObject> getAll();

    // Return all primary keys
    @Query("SELECT * FROM userobject WHERE UserID IN (:userIds)")
    List<UserObject> loadAllByIds(int[] userIds);

    // Return a specific entry from Login Database
    @Query("SELECT * FROM userobject WHERE username LIKE :first AND " +
            "password LIKE :last LIMIT 1")
    UserObject findByName(String first, String last);

    // Insert a new user
    @Insert
    void insertAll(UserObject... users);

    // Delete a user
    @Delete
    void delete(UserObject user);
}
