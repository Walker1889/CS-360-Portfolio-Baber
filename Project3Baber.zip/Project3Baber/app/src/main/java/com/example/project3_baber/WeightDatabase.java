package com.example.project2_baber;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {UserObject.class}, version = 1)
public abstract class WeightDatabase extends RoomDatabase {
    public abstract WeightDAO weightdao();
}
