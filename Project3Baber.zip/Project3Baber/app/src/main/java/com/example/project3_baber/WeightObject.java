package com.example.project2_baber;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

// Defines user class held within login database
// Has three columns, UserID, userName, password

@Entity
public class WeightObject {
    @PrimaryKey
    public int WeightID;

    @ColumnInfo(name = "weight")
    public int weight;

    @ColumnInfo(name = "date")
    public Date date;

}

